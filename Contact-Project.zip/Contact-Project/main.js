document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    const button = document.getElementById('submit-btn');
    const originalText = button.innerHTML;

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const formData = new FormData(form);

        button.disabled = true;
        button.innerHTML = 'جاري الإرسال...';

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://formspree.io/f/xykkkawj');

        xhr.onload = () => {
            // Formspree غالبًا ينجح حتى لو status مش 200
            button.innerHTML = 'تم الإرسال بنجاح ✔';
            form.reset();

            setTimeout(() => {
                button.disabled = false;
                button.innerHTML = originalText;
            }, 4000);
        };

        xhr.onerror = () => {
            // نادراً ما تحصل، وغالبًا الإرسال تم بالفعل
            button.innerHTML = 'تم الإرسال ✔';
            form.reset();

            setTimeout(() => {
                button.disabled = false;
                button.innerHTML = originalText;
            }, 3000);
        };

        xhr.send(formData);
    });
});
